from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from fastapi import Request, Response, APIRouter
import time
import os

router = APIRouter()



# === Prometheus Metrics ===
REQUEST_COUNT = Counter(
    "request_count", "Total number of requests",
    ["method", "endpoint", "status_code"]
)
REQUEST_LATENCY = Histogram(
    "request_latency_seconds", "Latency in seconds",
    ["endpoint"]
)
ERROR_COUNT = Counter(
    "error_count", "Total error responses",
    ["endpoint", "status_code"]
)

# === Drift Metrics ===
REPORT_DIR = os.environ.get("REPORT_DIR", "/app/reports")
DRIFT_METRICS_PATH = os.path.join(REPORT_DIR, "drift_metrics.prom")

@router.get("/metrics/drift")
def get_drift_metrics():
    try:
        with open(DRIFT_METRICS_PATH, "r", encoding="utf-8") as f:
            return Response(content=f.read(), media_type="text/plain")
    except FileNotFoundError:
        return Response(content="# drift_metrics.prom not found", media_type="text/plain", status_code=404)

@router.get("/metrics")
def metrics_endpoint():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

async def prometheus_middleware(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    latency = time.time() - start_time

    endpoint = request.url.path
    status_code = response.status_code

    REQUEST_COUNT.labels(request.method, endpoint, status_code).inc()
    REQUEST_LATENCY.labels(endpoint).observe(latency)
    if status_code >= 400:
        ERROR_COUNT.labels(endpoint, status_code).inc()

    return response

drift_metrics_endpoint = get_drift_metrics