import json
import os

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "pipeline_conf.json")

def load_pipeline_config() -> dict:
    """Loads the default pipeline configuration from JSON."""
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def save_pipeline_config(conf: dict) -> None:
    """Saves the given pipeline configuration to JSON."""
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(conf, f, indent=2)