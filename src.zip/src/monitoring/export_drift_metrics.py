#monitoring/export_drift_metrics.py
import os
import json

# Eingabe (von Evidently erzeugt)
REPORT_DIR = os.environ.get("REPORT_DIR", "/opt/airflow/reports")
DRIFT_JSON_PATH = os.path.join(REPORT_DIR, "drift_metrics.json")

# Ausgabe für Prometheus (einfache Textdatei)
METRIC_OUTPUT_PATH = os.path.join(REPORT_DIR, "drift_metrics.prom")

# Lade Evidently-Metriken
with open(DRIFT_JSON_PATH, "r", encoding="utf-8") as f:
    metrics = json.load(f)

lines = []

# ===: Beispiel-Metriken extrahieren
try:
    # 1. Data Drift Share
    data_drift_share = metrics["metrics"][0]["result"]["dataset_drift"]
    lines.append(f"data_drift_share {data_drift_share:.4f}")

    # 2. PSI (Population Stability Index) – für Zielwert
    target_psi = metrics["metrics"][1]["result"]["psi"]
    lines.append(f"target_drift_psi {target_psi:.4f}")

    # 3. Anz. gedrifteter Spalten
    n_drifted = metrics["metrics"][0]["result"]["number_of_drifted_columns"]
    lines.append(f"drifted_columns_total {n_drifted}")

    # 4. Anteil gedrifteter Spalten
    drift_ratio = metrics["metrics"][0]["result"]["share_of_drifted_columns"]
    lines.append(f"drifted_columns_share {drift_ratio:.4f}")

except Exception as e:
    lines.append(f'# Error parsing drift_metrics.json: {e}')

# Schreibe Prometheus-kompatibles Format
with open(METRIC_OUTPUT_PATH, "w", encoding="utf-8") as f:
    f.write("\n".join(lines) + "\n")

print(f"✅ Prometheus-Metriken gespeichert unter: {METRIC_OUTPUT_PATH}")