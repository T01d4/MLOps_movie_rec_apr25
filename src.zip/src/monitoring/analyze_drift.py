# ===: monitoring/analyze_drift.py ===

import pandas as pd
from evidently.report import Report
from evidently.metric_preset import DataDriftPreset, TargetDriftPreset
from evidently.pipeline.column_mapping import ColumnMapping
import json
import os

# Diese Pfade bleiben gleich, da sie in Docker gemountet sind
DATA_DIR = os.environ.get("DATA_DIR", "/opt/airflow/data")
REPORT_DIR = os.environ.get("REPORT_DIR", "/opt/airflow/reports")

CLEAN_DATA_DIR = os.path.join(DATA_DIR, "monitoring")
TRAIN_PATH = os.path.join(CLEAN_DATA_DIR, "train.csv")
TEST_PATH = os.path.join(CLEAN_DATA_DIR, "test.csv")
os.makedirs(REPORT_DIR, exist_ok=True)

train = pd.read_csv(TRAIN_PATH)
test = pd.read_csv(TEST_PATH)

# Optional: Automatische Spaltenerkennung
column_mapping = ColumnMapping()
column_mapping.target = "rating"  # ggf. anpassen

report = Report(metrics=[
    DataDriftPreset(),
    TargetDriftPreset()
])
report.run(reference_data=train, current_data=test, column_mapping=column_mapping)

report.save_html(os.path.join(REPORT_DIR, "drift_report.html"))
report.save_json(os.path.join(REPORT_DIR, "drift_metrics.json"))