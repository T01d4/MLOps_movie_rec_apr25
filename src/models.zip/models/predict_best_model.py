# src/models/predict_best_model.py

import pandas as pd
import os
import mlflow
from dotenv import load_dotenv
import argparse

load_dotenv()
mlflow.set_tracking_uri(os.getenv("MLFLOW_TRACKING_URI"))

MODEL_REGISTRY_NAMES = {
    "hybrid": "hybrid_model",
    "user": "user_model",
    "hybrid_dl": "hybrid_deep_model",
    "user_dl": "user_deep_model"
}

def predict_best_model(model_type: str, input_path: str, output_path: str):
    """
    model_type: hybrid, user, hybrid_dl, user_dl
    input_path: CSV-Datei mit Feature-Input
    output_path: Speichere Predictions als CSV
    """
    model_name = MODEL_REGISTRY_NAMES[model_type]
    model_uri = f"models:/{model_name}@best_model"   # Nehme immer das beste Modell per Alias!
    print(f"🚀 Lade Modell: {model_uri}")
    model = mlflow.pyfunc.load_model(model_uri)
    print(f"✅ Modell geladen")

    df = pd.read_csv(input_path)
    preds = model.predict(df)
    # predictions sind meist Index-Liste – ggf. auflösen!
    pred_df = pd.DataFrame({"input_index": df.index, "predictions": preds.tolist()})
    pred_df.to_csv(output_path, index=False)
    print(f"✅ Predictions gespeichert unter {output_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_type", type=str, required=True, choices=["hybrid", "user", "hybrid_dl", "user_dl"])
    parser.add_argument("--input_path", type=str, required=True)
    parser.add_argument("--output_path", type=str, required=True)
    args = parser.parse_args()
    predict_best_model(args.model_type, args.input_path, args.output_path)