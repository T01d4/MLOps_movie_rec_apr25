# src/models/validate_model.py

import pickle
import pandas as pd
import numpy as np
import mlflow
from dotenv import load_dotenv
import os
import logging
import argparse
from mlflow.tracking import MlflowClient

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
load_dotenv()
mlflow.set_tracking_uri(os.getenv("MLFLOW_TRACKING_URI"))
mlflow.set_experiment("model_validation")

MODEL_DIR = "/opt/airflow/models"

# --- Model Registry Namen
MODEL_REGISTRY_NAMES = {
    "hybrid": "hybrid_model",
    "user": "user_model",
    "hybrid_dl": "hybrid_deep_model",
    "user_dl": "user_deep_model"
}

# --- Zu ladende Modelle (Klassisch vs. DL)
MODEL_FILE_PATHS = {
    "hybrid": os.path.join(MODEL_DIR, "hybrid_model.pkl"),
    "user": os.path.join(MODEL_DIR, "user_model.pkl"),
    "hybrid_dl": os.path.join(MODEL_DIR, "hybrid_deep_knn.pkl"),
    "user_dl": os.path.join(MODEL_DIR, "user_deep_knn.pkl")
}

def validate_model(
    pipeline_type: str = "classic",  # classic oder dl
    test_user_count: int = 100
):
    """
    pipeline_type: classic (klassisch) oder dl (deep learning)
    """
    logging.info(f"🚀 Starte Validierung: {pipeline_type.upper()}")

    # Registry-Namen und Modellpfade festlegen
    if pipeline_type == "classic":
        hybrid_name = MODEL_REGISTRY_NAMES["hybrid"]
        user_name = MODEL_REGISTRY_NAMES["user"]
        hybrid_path = MODEL_FILE_PATHS["hybrid"]
        user_path = MODEL_FILE_PATHS["user"]
        matrix_path = "/opt/airflow/data/processed/hybrid_matrix.csv"
        features_path = "/opt/airflow/data/processed/hybrid_matrix_features.txt"
        user_matrix_path = "/opt/airflow/data/processed/user_matrix.csv"
        user_features_path = "/opt/airflow/data/processed/user_matrix_features.txt"
    else:
        hybrid_name = MODEL_REGISTRY_NAMES["hybrid_dl"]
        user_name = MODEL_REGISTRY_NAMES["user_dl"]
        hybrid_path = MODEL_FILE_PATHS["hybrid_dl"]
        user_path = MODEL_FILE_PATHS["user_dl"]
        matrix_path = "/opt/airflow/data/processed/hybrid_deep_embedding.csv"
        features_path = None  # Embeddings haben keine expliziten Features
        user_matrix_path = "/opt/airflow/data/processed/user_deep_embedding.csv"
        user_features_path = None

    client = MlflowClient()

    try:
        ratings = pd.read_csv("/opt/airflow/data/raw/ratings.csv")
        # Lade Matrix (mit Index userId für User-Modell)
        if pipeline_type == "classic":
            hybrid_matrix = pd.read_csv(matrix_path)
            user_matrix = pd.read_csv(user_matrix_path, index_col=0)
        else:
            hybrid_matrix = pd.read_csv(matrix_path, index_col=0)
            user_matrix = pd.read_csv(user_matrix_path, index_col=0)

        with open(hybrid_path, "rb") as f:
            hybrid_model = pickle.load(f)
        with open(user_path, "rb") as f:
            user_model = pickle.load(f)
        logging.info("📥 Daten & Modelle geladen – Beginne Evaluation")
    except Exception as e:
        logging.error(f"❌ Fehler beim Laden der Daten/Modelle: {e}", exc_info=True)
        return

    # --- User- und Hybrid-Evaluation (Top-10-Empfehlungen je User)
    test_users = list(user_matrix.index)[:test_user_count]
    hybrid_scores, user_scores, valid_users = [], [], []

    for uid in test_users:
        try:
            if pipeline_type == "classic":
                uvec_user = user_matrix.loc[uid].values.reshape(1, -1)
                # Hybrid klassisch: User-Vektor → Hybrid-Matrix-Features
                uvec_hybrid = hybrid_matrix[hybrid_matrix["movieId"] == uid].drop(columns=["movieId"]).values.reshape(1, -1)
            else:
                uvec_user = user_matrix.loc[uid].values.reshape(1, -1)
                # Hybrid DL: Der Index ist der Movie/UserId
                uvec_hybrid = hybrid_matrix.loc[uid].values.reshape(1, -1)
            if uvec_user.shape[1] != user_model.n_features_in_:
                raise ValueError(f"user_model erwartet {user_model.n_features_in_} Features, hat aber {uvec_user.shape[1]}")
            if uvec_hybrid.shape[1] != hybrid_model.n_features_in_:
                raise ValueError(f"hybrid_model erwartet {hybrid_model.n_features_in_} Features, hat aber {uvec_hybrid.shape[1]}")
            _, idxs_hybrid = hybrid_model.kneighbors(uvec_hybrid)
            if pipeline_type == "classic":
                rec_ids = hybrid_matrix.iloc[idxs_hybrid[0]]["movieId"].values
            else:
                rec_ids = hybrid_matrix.index[idxs_hybrid[0]]
            hit_hybrid = ratings[(ratings["userId"] == uid) & (ratings["movieId"].isin(rec_ids))]
            hybrid_scores.append(1 if not hit_hybrid.empty else 0)
            _, idxs_user = user_model.kneighbors(uvec_user)
            rec_user_ids = user_matrix.index[idxs_user[0]]
            hit_user = ratings[(ratings["userId"] == uid) & (ratings["movieId"].isin(rec_user_ids))]
            user_scores.append(1 if not hit_user.empty else 0)
            valid_users.append(uid)
        except Exception as e:
            logging.warning(f"⚠️ Fehler bei User {uid}: {e}")
            continue

    if len(valid_users) == 0:
        logging.error("❌ Keine gültigen Nutzer zur Auswertung!")
        return

    hybrid_mean = float(np.mean(hybrid_scores))
    user_mean = float(np.mean(user_scores))
    logging.info(f"📊 precision_10_hybrid: {hybrid_mean:.2f}")
    logging.info(f"📊 precision_10_user:   {user_mean:.2f}")

    # Logging in MLflow (als Run)
    try:
        with mlflow.start_run(run_name=f"validate_predictions_{pipeline_type}") as run:
            mlflow.set_tag("pipeline_type", pipeline_type)
            mlflow.set_tag("source", "airflow")
            mlflow.set_tag("task", "validate_models")
            mlflow.log_param("n_test_users", len(valid_users))
            mlflow.log_metric(f"precision_10_hybrid_{pipeline_type}", hybrid_mean)
            mlflow.log_metric(f"precision_10_user_{pipeline_type}", user_mean)
            score_df = pd.DataFrame({
                "user_id": valid_users,
                "hybrid_score": hybrid_scores,
                "user_score": user_scores
            })
            score_path = f"/opt/airflow/data/processed/validation_scores_{pipeline_type}.csv"
            score_df.to_csv(score_path, index=False)
            mlflow.log_artifact(score_path, artifact_path="validation")
    except Exception as e:
        logging.error(f"❌ Fehler beim Logging in MLflow: {e}", exc_info=True)
        return

    logging.info("🎉 Validation abgeschlossen.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--pipeline_type", type=str, default="classic", choices=["classic", "dl"])
    parser.add_argument("--test_user_count", type=int, default=100)
    args = parser.parse_args()
    validate_model(pipeline_type=args.pipeline_type, test_user_count=args.test_user_count)